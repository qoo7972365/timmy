package com.adventnet.appmanager.reporting.actions;

import org.apache.struts.actions.DispatchAction;

public class ReportActions
  extends DispatchAction
{
  public static final int LAST_ONE_HOUR = 1;
  public static final int LAST_TWELEVE_HOURS = 12;
  public static final int LAST_TWENTYFOUR_HOURS = 24;
  public static final int LAST_SEVEN_DAYS = 168;
  public static final int LAST_THIRTY_DAYS = 720;
  public static final int CURRENTDAY = 2;
  public static final int CURRENTWEEK = 3;
  public static final int CURRENTMONTH = 4;
}


/* Location:              C:\Program Files (x86)\ManageEngine\AppManager12\working\WEB-INF\lib\AdventNetAppManagerWebClient.jar!\com\adventnet\appmanager\reporting\actions\ReportActions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */