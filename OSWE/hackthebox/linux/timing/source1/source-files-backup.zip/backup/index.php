<?php
include_once "header.php";
?>

<h1 class="text-center" style="padding: 200px">You are logged in as user <?php echo $_SESSION['userid']; ?>!</h1>

<?php
include_once "footer.php";
?>
